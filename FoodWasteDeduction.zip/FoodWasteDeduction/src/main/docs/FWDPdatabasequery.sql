/*CREATE USER 'dbadmin'@'localhost' IDENTIFIED BY 'dbadmin';*/
GRANT ALL PRIVILEGES ON FWDP.* TO 'dbadmin'@'localhost';
DROP DATABASE IF EXISTS FWDP;
CREATE DATABASE FWDP;
USE FWDP;
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255),
    user_type ENUM('retailer', 'consumer', 'organization'),
    UNIQUE (email)
);
CREATE TABLE locations (
    location_id INT PRIMARY KEY AUTO_INCREMENT,
    location_name VARCHAR(255)
);
CREATE TABLE user_subscriptions (
    sub_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    location_id INT,
    communication_method ENUM('email', 'phone'),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
	FOREIGN KEY (location_id) REFERENCES locations(location_id)
);
CREATE TABLE food_type (
    food_id INT PRIMARY KEY AUTO_INCREMENT,
    food_name VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE user_food_preferences (
    user_id INT,
    food_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (food_id) REFERENCES food_type(food_id),
    PRIMARY KEY (user_id, food_id)
);

CREATE TABLE retailers (
    retailer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE,
	location_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
	FOREIGN KEY (location_id) REFERENCES locations(location_id)

);

CREATE TABLE consumers (
    consumer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE,
    sub_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
	FOREIGN KEY (sub_id) REFERENCES user_subscriptions(sub_id)
);

CREATE TABLE organizations (
    organization_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE,
    sub_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (sub_id) REFERENCES user_subscriptions(sub_id)
);


CREATE TABLE inventory (
    item_id INT PRIMARY KEY AUTO_INCREMENT,
    location_id INT,
    item_name VARCHAR(255),
    quantity INT,
    price float,
    discount float,
    expiration_date DATE,
	flagged BOOLEAN DEFAULT FALSE,
    donation BOOLEAN DEFAULT FALSE,
    food_id INT,
    FOREIGN KEY (food_id) REFERENCES food_type(food_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

CREATE TABLE login_history (
    login_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    item_id INT,
    quantity INT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (item_id) REFERENCES inventory(item_id)
);

select * from users;
select * from inventory;
select * from user_subscriptions;
select * from food_type;
select * from consumers;
select * from retailers;
select * from locations;
select * from organizations;
select * from user_subscriptions;
select * from user_food_preferences;

