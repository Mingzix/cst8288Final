-- Insert sample data into the users table
INSERT INTO users (name, email, password, user_type) 
VALUES 
('Mingzi Xu', 'mingzi@retailer.com', 'password123', 'retailer'),
('Alice Smith', 'alice@consumer.com', 'password456', 'consumer'),
('HelpUs Charity Organization', 'helpus@charity.com', 'password789', 'organization');

INSERT INTO locations (location_name) VALUES
('Barrheaven'),
('Kanata Lakes'),
('Orleans');
INSERT INTO food_type (food_name) VALUES 
('Fruit'),
( 'Vegetable'),
( 'Drink'),
( 'Snack'),
( 'Canned food'),
( 'Meat'),
( 'Diary'),
( 'Grain products');

-- Insert sample data into the user_subscriptions table
INSERT INTO user_subscriptions (user_id, location_id, communication_method)
VALUES 
(2, 2, 'phone'),
(3, 1, 'email');


INSERT INTO user_food_preferences (user_id, food_id) VALUES
(2, 4), -- User 2 prefers Snack
(2, 5), -- User 2 prefers Canned food
(3, 3), -- User 3 prefers Drink
(3, 6); -- User 3 prefers Meat-- Inserting locations

-- Insert sample data into the retailers table


INSERT INTO retailers (user_id,  location_id) 
VALUES 
(1, 1);

-- Insert sample data into the consumers table
INSERT INTO consumers (user_id, sub_id) 
VALUES 
(2,  1);

-- Insert sample data into the organizations table
INSERT INTO organizations (user_id,  sub_id) 
VALUES 
(3, 2);

-- Insert sample data into the inventory table
INSERT INTO inventory (location_id, item_name, quantity, price, discount, expiration_date,food_id, flagged, donation) 
VALUES 
(1, 'Apples', 100, 2.5, 0.2, '2024-12-31',1, false, false),
(1, 'Bananas', 50, 1.8, 0.1, '2024-12-31', 1, false, false),
(2, 'Oranges', 75, 3.0, 0.3, '2024-12-31',1,  false, false),
(3, 'Milk', 20, 2.0, 1, '2024-12-31',7,  false, true);

-- Insert sample data into the login_history table
INSERT INTO login_history (user_id, ip_address) 
VALUES 
(1, '192.168.0.1'),
(2, '192.168.0.2'),
(3, '192.168.0.3');

-- Insert sample data into the orders table
INSERT INTO orders (user_id, item_id, quantity)
VALUES 
(2, 1, 2), -- User 2 orders 2 Apples
(3, 3, 1), -- User 3 orders 1 Oranges
(3, 4, 3); -- User 3 orders 3 Milk

select * from users;
select * from inventory;
select * from user_subscriptions;
select * from food_type;
select * from consumers;
select * from retailers;
select * from locations;
select * from organizations;
select * from user_subscriptions;
select * from user_food_preferences;
select * from orders;