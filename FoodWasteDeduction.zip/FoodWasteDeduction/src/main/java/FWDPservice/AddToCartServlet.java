package FWDPservice;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class AddToCartServlet
 */
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession session = request.getSession();
	        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");
	        
	        if (cartItems == null) {
	            cartItems = new ArrayList<>();
	            session.setAttribute("cartItems", cartItems);
	        }

	        int itemId = Integer.parseInt(request.getParameter("itemId"));
	        int quantity = Integer.parseInt(request.getParameter("quantity"));

	        // Here you might want to fetch item details from the database based on the itemId
	        
	        // Create a new CartItem object and add it to the cart
	        CartItem cartItem = new CartItem(itemId, quantity);
	        cartItems.add(cartItem);

	        // Redirect to the shopping cart page
	        response.sendRedirect("viewShoppingCart.jsp");
    }

}
