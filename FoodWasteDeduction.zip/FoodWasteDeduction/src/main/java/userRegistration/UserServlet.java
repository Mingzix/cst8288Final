package userRegistration;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import FWDPdatabase.DatabaseConnector;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        // Retrieve form parameters
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            // Get connection from DatabaseConnector
            DatabaseConnector connector = DatabaseConnector.getInstance();

            // Get the connection
            try (Connection connection = connector.getConnection()) {
                // Prepare SQL statement
                String query = "SELECT * FROM users WHERE email = ? AND password = ?";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setString(1, email);
                    statement.setString(2, password);

                    // Execute query
                    try (ResultSet resultSet = statement.executeQuery()) {
                        // Check if a matching user is found
                        if (resultSet.next()) {
                            // User found, determine user type
                            String userType = resultSet.getString("user_type");
                            
                            // Forward request to user type-specific servlet
                            String servletPath = "/"; // Default servlet path
                            switch (userType) {
                                case "consumer":
                                    servletPath = "/ConsumerListServlet";
                                    break;
                                case "retailer":
                                    servletPath = "/RetailerListServlet";
                                    break;
                                case "charitableOrganization":
                                    servletPath = "/OrganizationServlet";
                                    break;
                                default:
                                    // Handle unknown user types or errors
                                    PrintWriter out = response.getWriter();
                                    out.println("<h1>Invalid user type. Please contact support.</h1>");
                                    return;
                            }
                            
                            // Forward the request to the appropriate servlet
                            RequestDispatcher dispatcher = request.getRequestDispatcher(servletPath);
                            dispatcher.forward(request, response);
                        } else {
                            // User not found, display error message
                            PrintWriter out = response.getWriter();
                            out.println("<h1>Invalid credentials. Please try again.</h1>");
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection or query errors
            // Display an error message or redirect to an error page
        }
    }
}