package userRegistration;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import FWDPdatabase.DatabaseConnector;

public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String userType = request.getParameter("userType");

        try {
            Connection conn = DatabaseConnector.getInstance().getConnection();
            PreparedStatement statement = conn.prepareStatement("INSERT INTO users (name, email, password, userType) VALUES (?, ?, ?, ?)");
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, password);
            statement.setString(4, userType);
            statement.executeUpdate();
            response.getWriter().println("User registered successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error occurred while registering user.");
        }
    }
}
