package userRegistration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import FWDPdatabase.DatabaseConnector;
import FWDPdatabase.InventoryItemDTO;
import FWDPdatabase.RetailerDAOImpl;
import FWDPdatabase.InventoryDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EditItemServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int itemId = Integer.parseInt(request.getParameter("itemId"));
        int retailerId = Integer.parseInt(request.getParameter("retailerId"));
        String itemName = request.getParameter("itemName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double discount = Double.parseDouble(request.getParameter("discount"));
        String expirationDateString = request.getParameter("expirationDate");
        String foodId = request.getParameter("food_id");

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date expirationDate;
        try {
            expirationDate = dateFormat.parse(expirationDateString);
        } catch (ParseException e) {
            e.printStackTrace();
            // Handle date parsing error
            return;
        }

        // Create InventoryItemDTO object with updated information
        InventoryItemDTO updatedItem = new InventoryItemDTO();

        // Establish database connection
        Connection connection = null;
        try {
            connection = DatabaseConnector.getInstance().getConnection();
            InventoryDAO inventoryDAO = new RetailerDAOImpl(connection);

            // Update the item in the database
            boolean success = inventoryDAO.updateInventoryItem(updatedItem);

            if (success) {
                // Item updated successfully, redirect to a success page
                response.sendRedirect("editItemSuccess.html");
            } else {
                // Failed to update the item, redirect to an error page
                response.sendRedirect("editItemError.html");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection error
        } finally {
            // Close the database connection
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
