package userRegistration;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import FWDPdatabase.DatabaseConnector;
import FWDPdatabase.InventoryItemDTO;

/**
 * Servlet implementation class CosumerListServlet
 */
public class CosumerListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CosumerListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection connection = DatabaseConnector.getInstance().getConnection()) {
            
        	 if (connection != null && !connection.isClosed()) {
                 System.out.println("Database connection established successfully.");
             } else {
                 System.out.println("Failed to establish database connection.");
             }
        	 
        	List<InventoryItemDTO> itemList = new ArrayList<>();

            String query = "SELECT i.item_id, i.item_name, i.quantity, i.discount, i.price, f.food_name, l.location_name \r\n"
            		+ "FROM inventory i \r\n"
            		+ "INNER JOIN food_type f ON i.food_id = f.food_id \r\n"
            		+ "INNER JOIN locations l ON i.location_id = l.location_id\r\n"
            		+ "WHERE i.donation = FALSE";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                // Add records into dataList
            	InventoryItemDTO item = new InventoryItemDTO();
                 item.setItemId(resultSet.getInt("item_id"));
                 item.setItemName(resultSet.getString("item_name"));
                 item.setQuantity(resultSet.getInt("quantity"));
                 item.setPrice(resultSet.getFloat("price"));
                 item.setDiscount(resultSet.getFloat("discount"));
                 item.setFoodType(resultSet.getString("food_type"));
                 item.setLocation(resultSet.getString("location_name"));
                 itemList.add(item);
            }

            request.setAttribute("itemlist", itemList);
            RequestDispatcher dispatcher = request.getRequestDispatcher("listAllItems.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection or query errors
            // Display an error message or redirect to an error page
        }
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
