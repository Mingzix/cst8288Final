package userRegistration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import FWDPdatabase.DatabaseConnector;
import FWDPdatabase.InventoryItemDTO;
import FWDPdatabase.RetailerDAOImpl;
import FWDPdatabase.InventoryDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AddItemServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int locationId = Integer.parseInt(request.getParameter("locationId"));
        String itemName = request.getParameter("itemName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double price = Double.parseDouble(request.getParameter("price"));

        double discount = Double.parseDouble(request.getParameter("discount"));
        String expirationDateString = request.getParameter("expirationDate");
        String itemType = request.getParameter("itemType");
        int foodId = Integer.parseInt(request.getParameter("foodId"));
        boolean flagged = Boolean.parseBoolean(request.getParameter("flagged"));
        boolean donation = Boolean.parseBoolean(request.getParameter("donation"));

        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date expirationDate;
        try {
            expirationDate = dateFormat.parse(expirationDateString);
        } catch (ParseException e) {
            e.printStackTrace();
            // Handle date parsing error
            return;
        }
        // Create InventoryItemDTO object for the new item
        InventoryItemDTO newItem = new InventoryItemDTO(0, locationId, itemName, quantity,price, discount, expirationDate,flagged,donation,foodId);

        // Establish database connection
        Connection connection = null;
        try {
             connection = DatabaseConnector.getInstance().getConnection();
            InventoryDAO inventoryDAO = new RetailerDAOImpl(connection);

            // Add the new item to the inventory
            boolean success = inventoryDAO.addInventoryItem(newItem);

            if (success) {
                // Item added successfully, redirect to a success page
                response.sendRedirect("addItemSuccess.html");
            } else {
                // Failed to add the item, redirect to an error page
                response.sendRedirect("addItemError.html");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection error
        } finally {
            // Close the database connection
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
