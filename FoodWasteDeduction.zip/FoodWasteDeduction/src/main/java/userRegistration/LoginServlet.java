package userRegistration;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import FWDPdatabase.DatabaseConnector;

public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        // Retrieve form parameters
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        DatabaseConnector databaseConnector = DatabaseConnector.getInstance();
        Connection connection = databaseConnector.getConnection();
        
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
      
            // Get the connection
            try {
                // Prepare SQL statement
                String query = "SELECT * FROM users WHERE email = ? AND password = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, email);
                statement.setString(2, password);

                    // Execute query
                resultSet = statement.executeQuery();
                        // Check if a matching user is found
                        if (resultSet.next()) {
                            // User found, determine user type and redirect to respective home page
                        	HttpSession session = request.getSession();
                            session.setAttribute("email", email);
                            session.setAttribute("password", password);
                            
                        	String userType = resultSet.getString("user_type");
                            switch (userType) {
                                case "consumer":
                                    response.sendRedirect("consumerHomePage.jsp");
                                    break;
                                case "retailer":
                                    response.sendRedirect("retailerHomePage.jsp");
                                    break;
                                case "charitableOrganization":
                                    response.sendRedirect("charitableOrgHomePage.jsp");
                                    break;
                                default:
                                    // Handle unknown user types or errors
                                    PrintWriter out = response.getWriter();
                                    out.println("<h1>Invalid user type. Please contact support.</h1>");
                                    break;
                            }
                        } else {
                            // User not found, display error message
                            PrintWriter out = response.getWriter();
                            out.println("<h1>Invalid credentials. Please try again.</h1>");
                        }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                // Close resources
                try {
                    if (resultSet != null) resultSet.close();
                    if (preparedStatement != null) preparedStatement.close();
                    databaseConnector.closeConnection(); // Close the database connection
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }