package userRegistration;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Servlet implementation class UserProfileServlet
 */
public class UserProfileServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        String userType = (String) session.getAttribute("userType");
        
        
        if (request.getSession().getAttribute("email") == null) {
            response.sendRedirect("login.html"); // Redirect to login page if not logged in
            return;
        }
        
        // Declare variables to hold user profile information
        String name = "";
        String email = "";
        String profileInfo = "";
        
        // Retrieve user information based on userType
        switch (userType) {
            case "retailer":
                // Logic to retrieve and display retailer profile information
                name = "Retailer Name";
                email = "retailer@example.com";
                profileInfo = "ID: 1234<br>Email: retailer@example.com<br>Address: 123 Main St, City, Country";
                break;
            case "consumer":
                // Logic to retrieve and display consumer profile information
                name = "Consumer Name";
                email = "consumer@example.com";
                profileInfo = "Name: Consumer Name<br>Email: consumer@example.com<br>Alert Preference: Email<br>Food Preference: Vegetarian<br>Pickup Location: XYZ Grocery Store";
                break;
            case "charitableOrganization":
            	  name = request.getParameter("name");
                  email = request.getParameter("email");
                 String location = request.getParameter("location");
                 String communicationMethod = request.getParameter("communicationMethod");
                 String foodPreference = request.getParameter("foodPreference");

                break;
            default:
                // Handle unknown or unsupported user types
                response.getWriter().println("Unknown user type");
                return;
        }
        
        // Set user profile attributes to be accessed by JSP
        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("profileInfo", profileInfo);
        
        // Forward the request to the userProfile.jsp for displaying the user profile
        RequestDispatcher dispatcher = request.getRequestDispatcher("/userProfile.jsp");
        dispatcher.forward(request, response);
    }
}
