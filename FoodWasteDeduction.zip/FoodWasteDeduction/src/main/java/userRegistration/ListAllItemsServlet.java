package userRegistration;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import FWDPdatabase.DatabaseConnector;
import FWDPdatabase.InventoryItemDTO;
import FWDPdatabase.RetailerDAOImpl;

@WebServlet("/listAllItems")
public class ListAllItemsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");

    	 // Establish database connection
        Connection connection = null;
        try {
            connection = DatabaseConnector.getInstance().getConnection();
            RetailerDAOImpl retailerDAO = new RetailerDAOImpl(connection);

            // Retrieve all inventory items
            List<InventoryItemDTO> inventoryItems = retailerDAO.getInventoryItems();

            // Set the retrieved items as a request attribute
            request.setAttribute("inventoryItems", inventoryItems);

            // Forward the request to a JSP page
            request.getRequestDispatcher("/list_inventory_items.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception appropriately
        } finally {
            // Close the database connection
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    // Handle exception appropriately
                }
            }
        }
    }
}