package FWDPdatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import userInfo.UserType;

// InventoryDAOImpl class implements the InventoryDAO interface
public class RetailerDAOImpl implements InventoryDAO {
    // JDBC variables for managing connection and executing queries
    private Connection connection ;
   

    // Constructor to establish database connection
    public RetailerDAOImpl(Connection connection) throws SQLException {
        // Establish connection using DatabaseConnector class
        this.connection = connection;
    }

    // Method to add a new inventory item
    @Override
    public boolean addInventoryItem(InventoryItemDTO item) {
    	try {
            String updateItemQuery = "UPDATE inventory SET quantity = ?, expiration_date = ?, item_name = ? WHERE item_id = ?";
            PreparedStatement updateItemStatement = connection.prepareStatement(updateItemQuery);
            updateItemStatement.setInt(1, item.getQuantity());
            updateItemStatement.setDate(2, new java.sql.Date(item.getExpirationDate().getTime()));
            updateItemStatement.setString(3, item.getItemName());
            updateItemStatement.setInt(4, item.getItemId());
            
            int rowsUpdated = updateItemStatement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

 // Method to update an existing inventory item
    @Override
    public boolean updateInventoryItem(InventoryItemDTO item) {
        try {
            String updateItemQuery = "UPDATE inventory SET quantity = ?, expiration_date = ?, item_name = ? WHERE item_id = ?";
            PreparedStatement updateItemStatement = connection.prepareStatement(updateItemQuery);
            updateItemStatement.setInt(1, item.getQuantity());
            updateItemStatement.setDate(2, new java.sql.Date(item.getExpirationDate().getTime()));
            updateItemStatement.setString(3, item.getItemName());
            updateItemStatement.setInt(4, item.getItemId());
            
            int rowsUpdated = updateItemStatement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }



    // Method to delete an inventory item
    @Override
    public boolean deleteInventoryItem(int itemId) {
        try {
            String deleteItemQuery = "DELETE FROM inventory WHERE item_id = ?";
            PreparedStatement deleteItemStatement = connection.prepareStatement(deleteItemQuery);
            deleteItemStatement.setInt(1, itemId);
            int rowsDeleted = deleteItemStatement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to retrieve all inventory items
    @Override
    public List<InventoryItemDTO> getInventoryItems() {
        List<InventoryItemDTO> inventory = new ArrayList<>();
        try {
            String sql = "SELECT i.*, f.food_name, l.location_name  "
                    + "FROM inventory i "
                    + "INNER JOIN food_type f ON i.food_id = f.food_id "
                    + "INNER JOIN locations l ON i.location_id = l.location_id";
            
            PreparedStatement selectInventoryStatement = connection.prepareStatement(sql);
            ResultSet resultSet = selectInventoryStatement.executeQuery();
            while (resultSet.next()) {
                int itemId = resultSet.getInt("item_id");
                String itemName = resultSet.getString("item_name");
                
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                double discount = resultSet.getDouble("discount");
                Date expirationDate = resultSet.getDate("expiration_date");
                boolean donation = resultSet.getBoolean("donation");
				boolean flagged = resultSet.getBoolean("flagged");
                String foodType = resultSet.getString("food_name");
                String location = resultSet.getString("location_name");
                InventoryItemDTO item = new InventoryItemDTO(itemId, location, itemName, quantity, price, discount, expirationDate, donation, flagged, foodType);
                inventory.add(item);
                }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return inventory;
    }

    //Surplus Food Identification
    @Override
    public List<InventoryItemDTO> identifySurplusFoodItems() {
        List<InventoryItemDTO> surplusItems = new ArrayList<>();
        try {
            // Calculate the date one week from now
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DAY_OF_YEAR, 7);
            Date oneWeekFromNow = calendar.getTime();

            // Query for items with expiration dates within the next week
            String selectSurplusItemsQuery = "SELECT * FROM inventory WHERE expiration_date <= ?";
            PreparedStatement selectSurplusItemsStatement = connection.prepareStatement(selectSurplusItemsQuery);
            selectSurplusItemsStatement.setDate(1, new java.sql.Date(oneWeekFromNow.getTime()));
            ResultSet resultSet = selectSurplusItemsStatement.executeQuery();

            // Process the results
            while (resultSet.next()) {
            	int itemId = resultSet.getInt("item_id");
                String itemName = resultSet.getString("item_name");
                String location = resultSet.getString("location_name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                double discount = resultSet.getDouble("discount");
                Date expirationDate = resultSet.getDate("expiration_date");
                boolean donation = resultSet.getBoolean("donation");
				boolean flagged = resultSet.getBoolean("flagged");
                String foodType = resultSet.getString("food_name");

                surplusItems.add(new InventoryItemDTO(itemId, location, itemName, quantity, price, discount, expirationDate, donation, flagged, foodType));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return surplusItems;
    }
    @Override
    public List<InventoryItemDTO> getSurplusFoodItemsForDonation(int retailerId) {
        List<InventoryItemDTO> surplusItemsForDonation = new ArrayList<>();
        try {
            // Calculate the date one week from now
            

            // Query for surplus food items with expiration dates within the next week
        	String selectSurplusItemsForDonationQuery = 
                    "SELECT i.item_id, i.item_name, i.quantity, i.discount, i.price, f.food_name, l.location_name " +
                    "FROM inventory i " +
                    "INNER JOIN food_type f ON i.food_id = f.food_id " +
                    "INNER JOIN locations l ON i.location_id = l.location_id " +
                    "WHERE i.donation = true";
        	PreparedStatement selectSurplusItemsForDonationStatement = connection.prepareStatement(selectSurplusItemsForDonationQuery);
            ResultSet resultSet = selectSurplusItemsForDonationStatement.executeQuery();

            // Process the results
            while (resultSet.next()) {
            	int itemId = resultSet.getInt("item_id");
                String itemName = resultSet.getString("item_name");
                String location = resultSet.getString("location_name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                double discount = resultSet.getDouble("discount");
                Date expirationDate = resultSet.getDate("expiration_date");
                boolean donation = resultSet.getBoolean("donation");
				boolean flagged = resultSet.getBoolean("flagged");
                String foodType = resultSet.getString("food_name");

                // Create InventoryItemDTO object and add to the list
                //int itemId, int locationId, String itemName, int quantity, double price, double discount, Date expirationDate, boolean flagged, boolean donation, int foodId
                surplusItemsForDonation.add(new InventoryItemDTO(itemId, location, itemName, quantity, price, discount, expirationDate, donation, flagged, foodType));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return surplusItemsForDonation;
    }

    // Method to get surplus food items for sale
    @Override
    public List<InventoryItemDTO> getSurplusFoodItemsForSale(int retailerId) {
        List<InventoryItemDTO> surplusItemsForSale = new ArrayList<>();
        try {
            // Query for surplus food items for sale (quantity > 0)
        	String selectSurplusItemsForDonationQuery = 
                    "SELECT i.item_id, i.item_name, i.quantity, i.discount, i.price, f.food_name, l.location_name " +
                    "FROM inventory i " +
                    "INNER JOIN food_type f ON i.food_id = f.food_id " +
                    "INNER JOIN locations l ON i.location_id = l.location_id " +
                    "WHERE i.discount != 1";
        	
        	PreparedStatement selectSurplusItemsForSaleStatement = connection.prepareStatement(selectSurplusItemsForDonationQuery);
            ResultSet resultSet = selectSurplusItemsForSaleStatement.executeQuery();

            // Process the results
            while (resultSet.next()) {
            	int itemId = resultSet.getInt("item_id");
                String itemName = resultSet.getString("item_name");
                String location = resultSet.getString("location_name");
                int quantity = resultSet.getInt("quantity");
                double price = resultSet.getDouble("price");
                double discount = resultSet.getDouble("discount");
                Date expirationDate = resultSet.getDate("expiration_date");
                boolean donation = resultSet.getBoolean("donation");
				boolean flagged = resultSet.getBoolean("flagged");
                String foodType = resultSet.getString("food_name");


                // Create InventoryItemDTO object and add to the list
                //int itemId, int locationId, String itemName, int quantity, double price, double discount, Date expirationDate, boolean flagged, boolean donation, int foodId
                surplusItemsForSale.add(new InventoryItemDTO(itemId, location, itemName, quantity, price, discount, expirationDate, donation, flagged, foodType));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return surplusItemsForSale;
    }

   
    
   
}
