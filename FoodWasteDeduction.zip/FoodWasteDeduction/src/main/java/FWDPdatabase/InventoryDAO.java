package FWDPdatabase;

import java.util.List;
import userInfo.UserType;

// InventoryDAO interface specifies CRUD operations for the inventory
public interface InventoryDAO {
    // Method to add a new inventory item
    boolean addInventoryItem(InventoryItemDTO item);
    
    boolean updateInventoryItem(InventoryItemDTO item);
    
    // Method to delete an inventory item
    boolean deleteInventoryItem(int itemId);

    // Method to retrieve all inventory items for a retailer
    List<InventoryItemDTO> getInventoryItems();
    
    //for retailers
    List<InventoryItemDTO> identifySurplusFoodItems(); // New method to identify surplus food items
    
    List<InventoryItemDTO> getSurplusFoodItemsForDonation(int retailerId); // New method to get surplus food items for donation
    List<InventoryItemDTO> getSurplusFoodItemsForSale(int retailerId); // New method to get surplus food items for sale
    
    
    //for consumers
   // boolean purchaseItem(int itemId);

}