// InventoryItemDTO class represents the Data Transfer Object for an inventory item
package FWDPdatabase;

import java.util.Date;

public class InventoryItemDTO {
    private int itemId;
    private String location;
    private String itemName;
    private int quantity;
    private double price;
    private double discount;
    private Date expirationDate;
    private boolean flagged;
    private boolean donation;
    private String foodType;

    // Constructors
    public InventoryItemDTO() {
    }

    public InventoryItemDTO(int itemId, String location, String itemName, int quantity, double price, double discount, Date expirationDate, boolean flagged, boolean donation, String foodType) {
        this.itemId = itemId;
        this.location = location;
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.discount = discount;
        this.expirationDate = expirationDate;
        this.flagged = flagged;
        this.donation = donation;
        this.foodType = foodType;
    }

    // Getters and Setters
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public boolean isFlagged() {
        return flagged;
    }

    public void setFlagged(boolean flagged) {
        this.flagged = flagged;
    }

    public boolean isDonation() {
        return donation;
    }

    public void setDonation(boolean donation) {
        this.donation = donation;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    // toString method
    @Override
    public String toString() {
        return "InventoryItemDTO{" +
                "itemId=" + itemId +
                ", locationId=" + location +
                ", itemName='" + itemName + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                ", discount=" + discount +
                ", expirationDate=" + expirationDate +
                ", flagged=" + flagged +
                ", donation=" + donation +
                ", foodType=" + foodType +
                '}';
    }
}
