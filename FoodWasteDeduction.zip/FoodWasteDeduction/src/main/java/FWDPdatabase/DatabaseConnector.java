package FWDPdatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DatabaseConnector {
	private static final String URL = "jdbc:mysql://localhost:3306/fwdp";
    private static final String USERNAME = "dbadmin";
    private static final String PASSWORD = "dbadmin";

    private static DatabaseConnector instance;
    private Connection connection;

    // Private constructor to prevent instantiation from outside
    private DatabaseConnector() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle exception appropriately
        }
    }

    // Static method to get the instance
    public static synchronized DatabaseConnector getInstance() {
        if (instance == null) {
            instance = new DatabaseConnector();
        }
        return instance;
    }

    // Method to get the connection
    public Connection getConnection() {
        return connection;
    }
    
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle exception appropriately
            }
        }
    }
}
