package FWDPdatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import userInfo.UserType;

public class ConsumerDAOImpl implements InventoryDAO{
	 // JDBC variables for managing connection and executing queries
    private Connection connection ;
   

    // Constructor to establish database connection
    public ConsumerDAOImpl(Connection connection) throws SQLException {
        // Establish connection using DatabaseConnector class
        this.connection = connection;
    }

	@Override
	public boolean addInventoryItem(InventoryItemDTO item) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateInventoryItem(InventoryItemDTO item) {
		  // SQL update statement to update the inventory item
        String sql = "UPDATE inventory SET quantity = ?, price = ? WHERE item_id = ?";

        try (
            // Establish a JDBC connection
            Connection connection = DatabaseConnector.getInstance().getConnection();
            // Prepare the SQL statement
            PreparedStatement statement = connection.prepareStatement(sql)
        ) {
            // Set parameters for the SQL statement
            statement.setInt(1, item.getQuantity());
            statement.setDouble(2, item.getPrice());
            statement.setInt(3, item.getItemId());

            // Execute the SQL statement
            int rowsUpdated = statement.executeUpdate();

            // Return true if at least one row was updated, otherwise false
            return rowsUpdated > 0;
        } catch (SQLException e) {
            // Handle any SQL exceptions
            e.printStackTrace();
            return false;
        }
    
	}

	@Override
	public boolean deleteInventoryItem(int itemId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<InventoryItemDTO> getInventoryItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<InventoryItemDTO> identifySurplusFoodItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<InventoryItemDTO> getSurplusFoodItemsForDonation(int retailerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<InventoryItemDTO> getSurplusFoodItemsForSale(int retailerId) {
		// TODO Auto-generated method stub
		return null;
	}

	

	

}
