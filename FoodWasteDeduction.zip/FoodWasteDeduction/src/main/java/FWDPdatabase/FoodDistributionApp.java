 package FWDPdatabase;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.apache.catalina.User;

public class FoodDistributionApp {
		 public static void main(String[] args) {
			 DatabaseConnector connector = DatabaseConnector.getInstance();

		        // Get the connection
		        Connection connection = connector.getConnection();

		        try {
		            // Check if the connection is valid
		            if (connection != null && !connection.isClosed()) {
		                System.out.println("Database connection successful!");
		            } else {
		                System.out.println("Failed to establish database connection.");
		            }
		        } catch (SQLException e) {
		            // Print error message if connection fails
		            System.err.println("Failed to check database connection:");
		            e.printStackTrace();
		        }
		    }
	}