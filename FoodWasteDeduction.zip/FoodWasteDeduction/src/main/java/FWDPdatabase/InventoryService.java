package FWDPdatabase;

import java.sql.Connection;
import java.sql.SQLException;

public class InventoryService {
    private Connection connection;

    public InventoryService() throws SQLException {
        this.connection = DatabaseConnector.getInstance().getConnection();
    }

    public InventoryDAO getDAOForUserType(String userType) {
    	try {
            switch (userType) {
                case "retailer":
                    return new RetailerDAOImpl(connection);
                case "consumer":
                    return new ConsumerDAOImpl(connection);
                case "organization":
                    return new CharitableOrgDAOImpl(connection);
                default:
                    throw new IllegalArgumentException("Invalid user type: " + userType);
            }
        } catch (SQLException e) {
            // Handle SQLException if needed
            e.printStackTrace();
            return null; // Or throw a custom exception
        }
    }
    
    // Close JDBC resources
    public void closeConnection() {
    	 try {
             if (connection != null) {
                 connection.close();
             }
         } catch (SQLException e) {
             // Handle SQLException if needed
             e.printStackTrace();
         }
    }
}
