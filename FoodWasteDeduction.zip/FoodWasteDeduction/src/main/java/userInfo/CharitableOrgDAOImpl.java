package userInfo;

import java.util.List;

public class CharitableOrgDAOImpl implements UserDAO{

	public CharitableOrgDAOImpl(int userId, String name, String email, String password, UserType userType) {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean addUser(UserDTO user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateUser(UserDTO user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteUser(int userId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public UserDTO getUserById(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDTO> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDTO> getUsersByType(String userType) {
		// TODO Auto-generated method stub
		return null;
	}

}
