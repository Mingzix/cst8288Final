package userInfo;




public enum UserType {
    RETAILER,
    CONSUMER,
    CHARITABLE_ORGANIZATION
}
