package userInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import FWDPdatabase.DatabaseConnector;

public class UserDAOImpl implements UserDAO{

	@Override
	public boolean addUser(UserDTO user) {
		 try (Connection connection = DatabaseConnector.getInstance().getConnection()) {
	            String query = "INSERT INTO users (name, email, user_type) VALUES (?, ?, ?)";
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setString(1, user.getName());
	            statement.setString(2, user.getEmail());
	            statement.setString(3, user.getUserType().toString());
	            int rowsInserted = statement.executeUpdate();
	            return rowsInserted > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	@Override
	public boolean updateUser(UserDTO user) {
		 try (Connection connection = DatabaseConnector.getInstance().getConnection()) {
	            String query = "UPDATE users SET name = ?, email = ?, user_type = ? WHERE id = ?";
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setString(1, user.getName());
	            statement.setString(2, user.getEmail());
	            statement.setString(3, user.getUserType().toString());
	            statement.setInt(4, user.getUserId());
	            int rowsUpdated = statement.executeUpdate();
	            return rowsUpdated > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	@Override
	public boolean deleteUser(int userId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public UserDTO getUserById(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDTO> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDTO> getUsersByType(String userType) {
		// TODO Auto-generated method stub
		return null;
	}

}
