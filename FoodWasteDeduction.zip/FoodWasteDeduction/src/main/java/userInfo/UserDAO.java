package userInfo;

import java.util.List;

public interface UserDAO {
	// Method to add a new user
    boolean addUser(UserDTO user);

    // Method to update an existing user
    boolean updateUser(UserDTO user);

    // Method to delete a user
    boolean deleteUser(int userId);

    // Method to retrieve a user by ID
    UserDTO getUserById(int userId);

    // Method to retrieve all users
    List<UserDTO> getAllUsers();

    // Method to retrieve users by type
    List<UserDTO> getUsersByType(String userType);
}
