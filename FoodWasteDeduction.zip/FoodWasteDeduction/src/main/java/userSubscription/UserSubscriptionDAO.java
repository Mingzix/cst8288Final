package userSubscription;

import java.util.List;

public interface UserSubscriptionDAO {
	boolean addSubscription (SubscriptionDTO userSub);
    boolean updateSubscription(SubscriptionDTO userSub);
    boolean deleteSubscription(SubscriptionDTO userSub);
    
    // Method to retrieve all subscriptions
    List<SubscriptionDTO> getAllSubscriptions();
}
