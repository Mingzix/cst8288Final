package userSubscription;

public class SubscriptionDTO {
    private int userId;
    private String location;
    private String communicationMethod;
    private String foodPreference;

    public SubscriptionDTO(int userId, String location, String communicationMethod, String foodPreference) {
        this.userId = userId;
        this.location = location;
        this.communicationMethod = communicationMethod;
        this.foodPreference = foodPreference;
    }

    // Getters and setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCommunicationMethod() {
        return communicationMethod;
    }

    public void setCommunicationMethod(String communicationMethod) {
        this.communicationMethod = communicationMethod;
    }

    public String getFoodPreference() {
        return foodPreference;
    }

    public void setFoodPreference(String foodPreference) {
        this.foodPreference = foodPreference;
    }
}
