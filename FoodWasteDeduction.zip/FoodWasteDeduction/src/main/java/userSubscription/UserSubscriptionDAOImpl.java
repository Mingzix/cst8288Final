package userSubscription;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import FWDPdatabase.DatabaseConnector;

public class UserSubscriptionDAOImpl implements UserSubscriptionDAO {

    @Override
    public boolean addSubscription(SubscriptionDTO userSub) {
        try (Connection connection = DatabaseConnector.getInstance().getConnection()) {
            String query = "INSERT INTO user_subscription (user_id, location, communication_method, food_preference) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, userSub.getUserId());
            statement.setString(2, userSub.getLocation());
            statement.setString(3, userSub.getCommunicationMethod());
            statement.setString(4, userSub.getFoodPreference());
            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateSubscription(SubscriptionDTO userSub) {
        try (Connection connection = DatabaseConnector.getInstance().getConnection()) {
            String query = "UPDATE user_subscription SET location = ?, communication_method = ?, food_preference = ? WHERE user_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, userSub.getLocation());
            statement.setString(2, userSub.getCommunicationMethod());
            statement.setString(3, userSub.getFoodPreference());
            statement.setInt(4, userSub.getUserId());
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteSubscription(SubscriptionDTO userSub) {
        try (Connection connection = DatabaseConnector.getInstance().getConnection()) {
            String query = "DELETE FROM user_subscription WHERE user_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, userSub.getUserId());
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<SubscriptionDTO> getAllSubscriptions() {
        List<SubscriptionDTO> subscriptions = new ArrayList<>();
        try (Connection connection = DatabaseConnector.getInstance().getConnection()) {
            String query = "SELECT * FROM user_subscription";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                SubscriptionDTO subscription = new SubscriptionDTO(0, query, query, query);
                subscription.setUserId(resultSet.getInt("user_id"));
                subscription.setLocation(resultSet.getString("location"));
                subscription.setCommunicationMethod(resultSet.getString("communication_method"));
                subscription.setFoodPreference(resultSet.getString("food_preference"));
                subscriptions.add(subscription);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return subscriptions;
    }
}
